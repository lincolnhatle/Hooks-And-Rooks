package com.example.androidexample;

import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class ConnectMain extends AppCompatActivity{
    private Button connectBtn;
    private EditText usernameEtx;
    private String BASE_URL = "ws://10.48.100.147:8080/chat/";
    usernameEtx =(EditText) findViewById(R.id.et);

    connectBtn =(Button) findViewById(R.id.bt);

    /* connect button listener */
        connectBtn.setOnClickListener(view ->

    {
        String serverUrl = BASE_URL + usernameEtx.getText().toString();

        // Establish WebSocket connection and set listener
        WebSocketManager.getInstance().connectWebSocket(serverUrl);
        WebSocketManager.getInstance().setWebSocketListener(ConnectMain.this);
    });

}
